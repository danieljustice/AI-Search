from Wrapper import Wrapper

if __name__ == '__main__':
    Wrapper().main()